#!/usr/bin/env python
'''
Classes to degap sequences but maintain annotations
'''

#####################
# IMPORT OPERATIONS #
#####################

import pdb

from copy import copy

###############
# AUTHOR INFO #
###############

__author__ = 'Michael Gruenstaeudl <m.gruenstaeudl@fu-berlin.de>'
__copyright__ = 'Copyright (C) 2016-2017 Michael Gruenstaeudl'
__info__ = 'nex2embl'
__version__ = '2017.01.31.1900'

#############
# DEBUGGING #
#############

# pdb.set_trace()

###########
# CLASSES #
###########


class DegapButMaintainAnno:
    ''' This class contains functions to degap DNA sequences while 
        maintaining annotations. Specifically, the functions remove 
        dashes from strings while maintaining annotations on these 
        strings. Only some of the implementations work if the charsets 
        are overlapping.
    Args:
        seq (str):      a string that represents an aligned DNA sequence;
                        example: "ATG-C"
        charsets (dict):a dictionary with gene names (str) as keys and lists 
                        of nucleotide positions (list) as values; example: 
                        {"gene_1":[0,1],"gene_2":[2,3,4]}
    Returns:
        tupl.   The return consists of the degapped sequence and the 
                corresponding degapped charsets; example: 
                (degapped_seq, degapped_charsets)
    Raises:
        currently nothing
    '''

    def __init__(self, seq, rmchar, charsets):
        self.seq = seq
        self.rmchar = rmchar
        self.charsets = charsets

    def degap(self):
        ''' This function works on overlapping charsets and is preferable over 
        "degap_legacy".
        Source: http://stackoverflow.com/questions/35233714/
        maintaining-overlapping-annotations-while-removing-dashes-from-string
        '''

        seq = self.seq
        rmchar = self.rmchar
        charsets = self.charsets

        annotations = copy(charsets)
        index = seq.find(rmchar)
        while index > -1:  # if any occurrence is found
            for gene_name, indices in annotations.items():
                if index in indices:
                    indices.remove(index)
                annotations[gene_name] = [e-1 if e > index else e
                                          for e in indices]
            seq = seq[:index] + seq[index+1:]
            index = seq.find(rmchar)
        return seq, annotations


class RmAmbigsButMaintainAnno:
    ''' This class removes ambiguous nucleotides from a DNA sequence
        while maintaining the annotations.
    Args:
        seq (str):      a string that represents an aligned DNA sequence;
                        example: "NNATGCNNN"
        charsets (dict):a dictionary with gene names (str) as keys and lists 
                        of nucleotide positions (list) as values; example: 
                        {"gene_1":[0,1,2,3],"gene_2":[4,5,6,7,8]}
    Returns:
        tupl.   The return consists of the shortened DNA sequence and 
                the corresponding shortened charsets; example: 
                (shortened_seq, shortened_charsets)
    Raises:
        currently nothing
    '''

    def __init__(self):
        pass

    @staticmethod
    def rm_leadambig(seq, rmchar, charsets):
        ''' This class removes leading ambiguous nucleotides from a DNA
            sequence while maintaining the annotations.
        '''
        if seq[0] == rmchar:
            lead_stripoff = len(seq)-len(seq.lstrip(rmchar))
            for gene_name, indices in charsets.items():
                indices_shifted = [i-lead_stripoff for i in indices]
                charsets[gene_name] = [i for i in indices_shifted if i >= 0]
            seq = seq[lead_stripoff:]

        return seq, charsets

    @staticmethod
    def rm_trailambig(seq, rmchar, charsets):
        ''' This class removes trailing ambiguous nucleotides from a DNA
            sequence while maintaining the annotations.
        '''
        if seq[-1] == rmchar:
            trail_stripoff = len(seq.rstrip(rmchar))
            range_stripoff = range(trail_stripoff, len(seq))
            for gene_name, indices in charsets.items():
                indices_new = copy(indices)
                for index in range_stripoff:
                    if index in indices_new:
                        indices_new.remove(index)
                #    else:
                #        print "Warning: Index %s out of range." %(index)
                charsets[gene_name] = indices_new
            seq = seq[:trail_stripoff]
        return seq, charsets

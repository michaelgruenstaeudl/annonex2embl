# To run the unittests outside of 'python setup.py test':
```
python -m unittest discover -s /home/michael_science/git/michaelgruenstaeudl_annonex2embl/tests -p "*_test.py"
```

### Usage via Bash - Example 1
```
SCRIPT=scripts/annonex2embl.py
INF1=tests/data/input/Amaranths_ITS_subset_ALIGN.nex
INF2=tests/data/input/Amaranths_ITS_subset_META.csv
OUTF=tests/data/temp/Amaranths_ITS_subset_ALIGN.embl
EMAIL=mi.gruenstaeudl@gmail.com

python2 $SCRIPT -n $INF1 -c $INF2 -o $OUTF -e $EMAIL
```

### Usage via Bash - Example 2
```
SCRIPT=scripts/annonex2embl.py
INF1=tests/data/input/Test1_ALIGNM.nex
INF2=tests/data/input/Test1_META.csv
OUTF=tests/data/temp/Test1_ALIGNM.embl
EMAIL=mi.gruenstaeudl@gmail.com

python2 $SCRIPT -n $INF1 -c $INF2 -o $OUTF -e $EMAIL
```

